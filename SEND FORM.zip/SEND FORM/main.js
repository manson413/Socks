$('form .black-btn').click(function(){
        $('.input-wrap').removeClass('error');
    	var formId = $(this).closest('form').attr('id');
    	var str = $('#'+formId).serialize();
    	var formArr = $('#'+formId).serializeArray();
		var errorCounter = 0;
        // for(var key in formArr){
         //    if(formArr[key].value === ''){
         //    	console.log(formArr[key].name);
         //        errorCounter++;
         //        $('#'+formId+' input[name='+formArr[key].name+']').parent().addClass('error');
		// 	}
		// }
		if(errorCounter === 0 && formArr === 0){
            sendAjaxForm(str, 'new-send.php', formId);
		}
    	return false;
	});

        function sendAjaxForm(data, url, formId){
        $.ajax({
            url: url,
            type: "POST",
            dataType: "text",
            data: data,
            success: function(result) {
				$('#'+formId)[0].reset();
				if($('#'+formId).closest('.modal')){
					var modalId = $('#'+formId).closest('.modal').attr('id');
					$('#'+modalId).modal('hide');
				}
				$('#thanks').modal('show');
            },
            error: function() {
                console.log('Ошибка. Данные не отправлены.');
            }
        });
	}